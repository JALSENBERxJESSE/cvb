from flask import Flask, send_from_directory, render_template_string
import os

app = Flask(__name__, static_folder='static', template_folder='.')

@app.route('/')
def index():
    return send_from_directory('.', 'index.html')

# Servir archivos estáticos automáticamente desde /static/*

if __name__ == '__main__':
    port = int(os.environ.get('PORT', 5000))
    app.run(debug=True, port=port)