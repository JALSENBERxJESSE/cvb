```markdown
# To‑Do List con Local Storage

Esta es una aplicación To‑Do simple que guarda las tareas en `localStorage` del navegador. Funciona sin servidor; solo abre `index.html` en tu navegador.

Características principales:
- Añadir, editar (doble clic), marcar completadas y eliminar tareas.
- Filtrado: Todas / Activas / Completadas.
- Exportar e importar tareas en JSON.
- Persistencia en `localStorage`.

Estructura recomendada:
- index.html
- static/
  - css/styles.css
  - js/app.js

Cómo usar (modo rápido):
1. Abrir `index.html` con tu navegador (doble clic o `File -> Open`).
2. Escribe una tarea y pulsa Enter o el botón "Agregar".
3. Marca las tareas como completadas con la casilla.
4. Doble clic en una tarea para editarla.
5. Usa "Exportar JSON" para respaldar o "Importar JSON" para restaurar.

Opcional: servir con Python / Flask
1. Crear un entorno virtual:
   - python -m venv venv
   - venv\Scripts\activate (Windows) o source venv/bin/activate (macOS / Linux)
2. Instalar dependencias:
   - pip install -r requirements.txt
3. Ejecutar:
   - python app.py
4. Abrir http://127.0.0.1:5000

Si quieres, puedo:
- Subir estos archivos a tu repo `JALSENBERxJESSE/prueba_api`.
- Crear automáticamente un branch con el esqueleto.
- Añadir tests (p. ej. pruebas E2E con Playwright) o mejoras (ordenar, prioridades, etiquetas).
```