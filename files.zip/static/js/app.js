// Key de localStorage
const STORAGE_KEY = 'todos-v1';

// Estado en memoria
let todos = [];
let filter = 'all';

// Elementos DOM
const input = document.getElementById('task-input');
const addBtn = document.getElementById('add-btn');
const listEl = document.getElementById('task-list');
const remainingCount = document.getElementById('remaining-count');
const filters = document.querySelectorAll('.filters button');
const clearCompletedBtn = document.getElementById('clear-completed');
const exportBtn = document.getElementById('export');
const importBtn = document.getElementById('import');
const importFile = document.getElementById('import-file');

// Inicialización
load();
render();

// Eventos
addBtn.addEventListener('click', handleAdd);
input.addEventListener('keydown', e => { if (e.key === 'Enter') handleAdd(); });

filters.forEach(btn => btn.addEventListener('click', () => {
  filters.forEach(b=>b.classList.remove('active'));
  btn.classList.add('active');
  filter = btn.dataset.filter;
  render();
}));

clearCompletedBtn.addEventListener('click', () => {
  todos = todos.filter(t => !t.completed);
  save();
  render();
});

exportBtn.addEventListener('click', () => {
  const dataStr = JSON.stringify(todos, null, 2);
  const blob = new Blob([dataStr], {type: 'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `todos-export-${new Date().toISOString().slice(0,10)}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
});

importBtn.addEventListener('click', () => importFile.click());
importFile.addEventListener('change', handleImport);

// Funciones principales
function handleAdd(){
  const text = input.value.trim();
  if(!text) return;
  const task = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2,7)}`,
    text,
    completed: false,
    createdAt: new Date().toISOString()
  };
  todos.unshift(task);
  input.value = '';
  save();
  render();
}

function toggleComplete(id){
  todos = todos.map(t => t.id === id ? {...t, completed: !t.completed} : t);
  save();
  render();
}

function deleteTask(id){
  todos = todos.filter(t => t.id !== id);
  save();
  render();
}

function startEdit(id, liEl){
  const task = todos.find(t => t.id === id);
  if(!task) return;
  liEl.querySelector('.text').style.display = 'none';
  const inputEdit = document.createElement('input');
  inputEdit.className = 'edit-input';
  inputEdit.value = task.text;
  liEl.querySelector('.controls-right').prepend(inputEdit);
  inputEdit.focus();

  function done(){
    const newVal = inputEdit.value.trim();
    if(newVal) {
      todos = todos.map(t => t.id === id ? {...t, text: newVal} : t);
      save();
    }
    inputEdit.remove();
    liEl.querySelector('.text').style.display = '';
    render();
  }

  inputEdit.addEventListener('keydown', e => {
    if(e.key === 'Enter') done();
    if(e.key === 'Escape') { inputEdit.remove(); liEl.querySelector('.text').style.display = ''; }
  });
  inputEdit.addEventListener('blur', done);
}

function save(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(todos));
}

function load(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw) todos = JSON.parse(raw);
  }catch(e){
    console.error('Error leyendo localStorage', e);
    todos = [];
  }
}

function render(){
  listEl.innerHTML = '';

  const shown = todos.filter(t => {
    if(filter === 'active') return !t.completed;
    if(filter === 'completed') return t.completed;
    return true;
  });

  if(shown.length === 0){
    const empty = document.createElement('li');
    empty.className = 'task-item';
    empty.style.justifyContent = 'center';
    empty.textContent = 'No hay tareas';
    listEl.appendChild(empty);
  }

  shown.forEach(t => {
    const li = document.createElement('li');
    li.className = 'task-item';
    const chk = document.createElement('input');
    chk.type = 'checkbox';
    chk.checked = t.completed;
    chk.addEventListener('change', () => toggleComplete(t.id));

    const text = document.createElement('div');
    text.className = 'text' + (t.completed ? ' completed' : '');
    text.textContent = t.text;
    text.title = 'Doble click para editar';
    text.addEventListener('dblclick', () => startEdit(t.id, li));

    const right = document.createElement('div');
    right.className = 'controls-right';
    right.style.display = 'flex';
    right.style.gap = '8px';
    right.style.alignItems = 'center';

    const del = document.createElement('button');
    del.innerHTML = 'Eliminar';
    del.addEventListener('click', () => {
      if(confirm('¿Eliminar tarea?')) deleteTask(t.id);
    });

    right.appendChild(del);

    li.appendChild(chk);
    li.appendChild(text);
    li.appendChild(right);

    listEl.appendChild(li);
  });

  const remaining = todos.filter(t => !t.completed).length;
  remainingCount.textContent = `${remaining} tarea${remaining !== 1 ? 's' : ''} pendientes`;
}
  
function handleImport(ev){
  const file = ev.target.files?.[0];
  if(!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    try{
      const imported = JSON.parse(e.target.result);
      if(!Array.isArray(imported)) throw new Error('Formato inválido');
      // Merge: añadimos los importados al inicio (sin duplicados por id)
      const existingIds = new Set(todos.map(t => t.id));
      const toAdd = imported.filter(t => t && t.id && !existingIds.has(t.id));
      todos = [...toAdd, ...todos];
      save();
      render();
      importFile.value = '';
      alert(`Importadas ${toAdd.length} tareas`);
    }catch(err){
      alert('Error al importar: ' + err.message);
    }
  };
  reader.readAsText(file);
}